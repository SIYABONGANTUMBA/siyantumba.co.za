<?php
// about.php: built from the same pattern as index.php.
$pageTitle       = "About | Siyabonga Ntumba";
$pageDescription = "Siyabonga Ntumba: IT systems technician and junior full stack developer. Introduction, mission, education, certificates and work experience.";
$activePage      = "about";   // highlights this page in the menu
$pageScripts     = [];

// Photo: put your picture at public_html/main/assets/images/siyabonga.jpg
$photoFile = "/assets/images/siyabonga.jpg";
$hasPhoto  = is_file(__DIR__ . $photoFile);

// Badges: small images shown in one row by your name. Edit the "alt" text to name each badge.
// A badge that has no file yet is simply skipped.
$badges = [];
foreach ([1, 2, 3, 4] as $n) {
    $file = "/assets/documents/badge-$n.png";
    if (is_file(__DIR__ . $file)) {
        $badges[] = ["src" => $file, "alt" => "Certification badge $n"];
    }
}

// Documents people can download. The matric certificate is password protected (see download.php).
$docs = [
    ["label" => "CV",                   "file" => "/assets/documents/cv.pdf",         "name" => "Siyabonga-Ntumba-CV.pdf",         "locked" => false],
    ["label" => "Certificate transcript", "file" => "/assets/documents/transcript.pdf", "name" => "Siyabonga-Ntumba-Transcript.pdf", "locked" => false],
    ["label" => "Matric certificate",   "file" => "/assets/documents/matric.pdf",     "name" => "",                                "locked" => true],
];
$matricMsg = $_GET["matric"] ?? "";

$mission = "To keep learning, and to build and support technology that is reliable and useful: from the network and the hardware, up to the website people see.";

$education = [
    ["2026", "FET Certificate NQF4: Systems Development", "Certificate not yet issued."],
    ["2017", "Grade 12: Maths and Science", ""],
];

$certificates = [
    ["2020", "Google IT Support Professional Certificate"],
    ["2023", "Cisco Networking Support Technician"],
    ["2024", "Cisco Junior Cybersecurity"],
    ["2026", "Cisco IT Support Technician"],
];

$experience = [
    [
        "company" => "Utopianex Technologies",
        "place"   => "Randjespark, Midrand",
        "role"    => "Software dev intern",
        "dates"   => "03/2026 to present",
        "points"  => [
            "Full stack web development (HTML, CSS, JavaScript, PHP)",
            "REST APIs (PHP, AJAX, JSON)",
            "Basic SEO",
            "Database administration (phpMyAdmin, SQL)",
            "Integrating payment systems (Paystack, PayFast)",
            "Basic IT support (troubleshooting)",
            "Server side systems management",
        ],
    ],
];

require __DIR__ . "/includes/header.php";
?>

<section class="page-top about">
  <div class="about-head">
    <div class="about-photo">
      <?php if ($hasPhoto): ?>
        <img src="<?= asset($photoFile) ?>" alt="Photo of Siyabonga Ntumba" width="200" height="200">
      <?php else: ?>
        <span class="about-initials" role="img" aria-label="Photo of Siyabonga Ntumba coming soon">SN</span>
      <?php endif; ?>
    </div>
    <div class="about-id">
      <h2>Siyabonga Ntumba</h2>
      <p class="lead">IT Systems Technician &middot; Full stack web developer &middot; Junior software dev</p>
      <?php if ($badges): ?>
      <ul class="badges" aria-label="Certification badges">
        <?php foreach ($badges as $b): ?>
          <li><img src="<?= asset($b["src"]) ?>" alt="<?= htmlspecialchars($b["alt"]) ?>" width="125" height="125" loading="lazy"></li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
      <p class="about-mission"><span>Mission</span> <?= htmlspecialchars($mission) ?></p>
    </div>
  </div>

  <h3 class="sub">A little about me</h3>
  <div class="prose">
    <p>I am a creative and enthusiastic IT technician with a solid foundation in computer hardware, networking, cloud platforms and full stack web development, and a keen interest in cybersecurity.</p>
    <p>I started on the technician side, fixing hardware and software problems and working with networks, and moved into building websites and web applications. Today I work as a software dev intern, writing PHP, JavaScript and SQL for real client projects, and I build my own projects on the side, including this portfolio.</p>
    <p>I am based in Midrand, Gauteng, and I am looking for the next place to learn, contribute and grow.</p>
  </div>

  <h3 class="sub">Mini CV</h3>
  <div class="cv">
    <details class="cv-item" open>
      <summary>Work experience</summary>
      <div class="cv-body">
        <?php foreach ($experience as $job): ?>
          <div class="cv-entry">
            <h4><?= htmlspecialchars($job["role"]) ?> <span>at <?= htmlspecialchars($job["company"]) ?></span></h4>
            <p class="cv-meta"><?= htmlspecialchars($job["dates"]) ?> &middot; <?= htmlspecialchars($job["place"]) ?></p>
            <ul>
              <?php foreach ($job["points"] as $p): ?><li><?= htmlspecialchars($p) ?></li><?php endforeach; ?>
            </ul>
          </div>
        <?php endforeach; ?>
      </div>
    </details>

    <details class="cv-item">
      <summary>Education</summary>
      <div class="cv-body">
        <?php foreach ($education as $e): ?>
          <div class="cv-entry">
            <p class="cv-year"><?= htmlspecialchars($e[0]) ?></p>
            <h4><?= htmlspecialchars($e[1]) ?></h4>
            <?php if ($e[2] !== ""): ?><p class="cv-meta"><?= htmlspecialchars($e[2]) ?></p><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </details>

    <details class="cv-item">
      <summary>Certificates</summary>
      <div class="cv-body">
        <?php foreach ($certificates as $c): ?>
          <div class="cv-entry">
            <p class="cv-year"><?= htmlspecialchars($c[0]) ?></p>
            <h4><?= htmlspecialchars($c[1]) ?></h4>
          </div>
        <?php endforeach; ?>
      </div>
    </details>
  </div>

  <h3 class="sub" id="documents">Documents</h3>
  <ul class="docs">
    <?php foreach ($docs as $d): $exists = is_file(__DIR__ . $d["file"]); ?>
      <li class="doc">
        <span class="doc-name"><?= htmlspecialchars($d["label"]) ?><?= $d["locked"] ? ' <small>(password protected)</small>' : '' ?></span>
        <?php if (!$exists): ?>
          <span class="doc-soon">Coming soon</span>
        <?php elseif (!$d["locked"]): ?>
          <a class="btn" href="<?= htmlspecialchars($d["file"]) ?>" download="<?= htmlspecialchars($d["name"]) ?>">Download PDF</a>
        <?php else: ?>
          <form class="doc-lock" method="post" action="/download.php">
            <label for="matric-pw" class="sr-only">Password for the matric certificate</label>
            <input id="matric-pw" name="password" type="password" placeholder="Password" required autocomplete="off">
            <button class="btn" type="submit">Unlock and download</button>
          </form>
          <?php if ($matricMsg === "wrong"): ?>
            <p class="doc-error" role="alert">That password is not right. Please try again.</p>
          <?php elseif ($matricMsg === "missing"): ?>
            <p class="doc-error" role="alert">The file is not available right now.</p>
          <?php endif; ?>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
  <p class="cv-meta">Need the password for the matric certificate? Ask me at <a href="mailto:contact@siyantumba.co.za">contact@siyantumba.co.za</a>.</p>

  <p class="section-more"><a class="btn" href="/">Back to home</a></p>
</section>

<?php require __DIR__ . "/includes/footer.php";
